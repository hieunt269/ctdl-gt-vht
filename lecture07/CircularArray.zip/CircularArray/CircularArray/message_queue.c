//
//  message_queue.c
//  CircularArray
//
//  Created by TungDT on 8/1/20.
//  Copyright © 2020 macOne. All rights reserved.
//

#include "message_queue.h"
#include <string.h>
void clear_queue(void)
{    
    front = rear = -1;
}
int is_empty(void)
{
    return front == -1;
}
int is_full(void)
{
    if (front == rear + 1) return TRUE;
    if (front == 0 && rear == BUFFER_SIZE - 1) return TRUE;
    return FALSE;
}
void enqueue(char* msg)
{
// TODO:
//    Check if queue is full
//    Else
//        If queue is empty front = 0
//        Increase rear (go back if needed)
//        Add message to rear position
}
char* dequeue(void)
{
//TODO:
//    Check if message is empty
//        Else
//        Get message at front
//        If there is one message, clear queue
//        Else increase front (go back if needed)
}
int size(void)
{
    // [][][r][][][][f][][][]
    if (front <= rear) return rear - front + 1;
    else return BUFFER_SIZE - (front - rear - 1);
}
void overflow(char* msg)
{
    printf("%s\n", msg);
    exit(1);
}
