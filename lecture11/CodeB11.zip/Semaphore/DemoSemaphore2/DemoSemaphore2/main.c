//
//  main.c
//  DemoSemaphore2
//
//  Created by TungDT on 8/26/20.
//  Copyright © 2020 macOne. All rights reserved.
//

#include "thread_pool.h"
#include <semaphore.h>
#include <pthread.h>
#include <unistd.h>

#define NREQUESTS 20
#define POOL_SIZE 5
#define HANDLE_TIME 5
#define REQUEST_RATE 3

// global semaphore
sem_t semaphore;
// global thread pool (which is shared resouces)
thread_pool* pool;

void* handle_request(void* threadid);

int main(int argc, const char * argv[])
{
    pthread_t req_threads[NREQUESTS];
    // init randomizer
    time_t t;
    srand((unsigned) time(&t));
    
    const int THREAD_ONLY = 0;
    sem_init(&semaphore, THREAD_ONLY, POOL_SIZE);
    pool = init_pool(POOL_SIZE);
    
    dump(pool, -1, -1);
    
    for (int rq_id = 0; rq_id < NREQUESTS; rq_id++)
    {
        pthread_create(&req_threads[rq_id], NULL, handle_request, (void*)rq_id);
        // simulate waiting time for new request
        sleep(rand() % REQUEST_RATE);
    }
    
    // waiting other threads to finish
    for (int rq_id = 0; rq_id < NREQUESTS; rq_id++)
    {
        pthread_join(req_threads[rq_id], NULL);
    }
    clean_pool(&pool);
    pthread_exit(NULL);
    return 0;
}

void* handle_request(void* req_id)
{
    int req = (int) req_id;
    
    printf("Incomming request %d. Getting thread from pool ... \n", req);
    sem_wait(&semaphore); // wait for signal
    int tid = get_thread(&pool);
    if (tid == NO_THREAD)
    {
        perror("Something wrong with thread pool!\n");
        return NULL;
    }
    printf("Thread %d awakes to handle request %d\n", tid, req);
    
    sleep(rand() % HANDLE_TIME); // simulate time to handle request
    
    printf("Thread %d finishes. Go back to pool...\n", tid);
    free_thread(&pool, tid);
    
    dump(pool, req, tid);
    sem_post(&semaphore); // signal that one resource is released
    
    
    pthread_exit(NULL);
}
