//
//  jobs.h
//  QueueJobs
//
//  Created by TungDT on 8/2/20.
//  Copyright © 2020 macOne. All rights reserved.
//

#ifndef jobs_h
#define jobs_h

#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

#define TRUE        1
#define FALSE       0

#define NTHREADS 50
#define NO_THREAD -1
#define AVAILABLE 1
#define NOT_AVAILABLE 0

typedef struct
{
    int *threads;
    int *available;
    int thread_ptr;
    int size;
} thread_pool;

thread_pool* init_pool(const int size);
int get_thread(thread_pool** pool);
void free_thread(thread_pool** pool, const int pos);
void clean_pool(thread_pool** pool);
void dump(thread_pool *pool, int req, int tid);

#endif /* jobs_h */
