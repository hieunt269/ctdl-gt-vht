//
//  jobs.c
//  QueueJobs
//
//  Created by TungDT on 8/2/20.
//  Copyright © 2020 macOne. All rights reserved.
//

#include "thread_pool.h"
pthread_mutex_t locker;

thread_pool* init_pool(const int size)
{
    thread_pool *pool = (thread_pool*) malloc(sizeof(thread_pool));
    pool->threads = (int*) malloc(size * sizeof(int));
    pool->available = (int*) malloc(size * sizeof(int));
    // TODO: NULL check for pool, threads, available
    for (int i = 0; i < size; i++)
    {
        pool->threads[i] = i;
        pool->available[i] = AVAILABLE;
    }
    pool->thread_ptr = -1;
    pool->size = size;
    
    return pool;
}
int get_thread(thread_pool** pool)
{
    for (int i = 0; i < (*pool)->size; i++)
    {
        (*pool)->thread_ptr = ((*pool)->thread_ptr + 1) % (*pool)->size;
        int pos = (*pool)->thread_ptr;
        if ((*pool)->available[pos])
        {
            (*pool)->available[pos] = NOT_AVAILABLE;
            int tid = (*pool)->threads[pos];
            return tid;
        }
    }
    return NO_THREAD;
}
void free_thread(thread_pool** pool, const int pos)
{
    if (pos < 0 || pos >= (*pool)->size) return;
    
    if ((*pool)->available[pos]) return;
    
    (*pool)->available[pos] = AVAILABLE;
}
void clean_pool(thread_pool** pool)
{
    free((*pool)->threads);
    free((*pool)->available);
    free(*pool);
    *pool = NULL;
}

void dump(thread_pool *pool, int req, int tid)
{
    printf("~~~~~~~~~ THREAD POOL INFO - REQ %d TID %d ~~~~~~~~~\n", req, tid);
    printf("Threads: ");
    for (int i = 0; i < pool->size; i++)
    {
        printf("[%2d]", pool->threads[i]);
    }
    printf("\nAvails : ");
    for (int i = 0; i < pool->size; i++)
    {
        printf("[%2d]", pool->available[i]);
    }
    printf("\n");
}
