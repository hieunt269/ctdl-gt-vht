//
//  main.c
//  DemoSemaphore
//
//  Created by TungDT on 8/26/20.
//  Copyright © 2020 macOne. All rights reserved.
//

#include <stdio.h>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>
sem_t semaphore;
void* thread(void* arg)
{
    int semval = -1;
    int tid = (int) arg;
    
    sem_wait(&semaphore); // wait for signal
    
    printf("Get signal, now %d can use resource ..\n", tid);
    
    sem_getvalue(&semaphore, &semval);
    printf("Semaphore value after getting signal: %d\n", semval);
    
    sleep(4); // simulate doing something in 4s
    
    printf("\nCompleted...\n");
    
    sem_post(&semaphore); // signal that one resource is released
    
    sem_getvalue(&semaphore, &semval);
    printf("Semaphore value after sending signal: %d\n", semval);
    
    pthread_exit(NULL);
}
int main() {
    const int THREAD_ONLY = 0;
    const int SEM_VALUE = 1;
    sem_init(&semaphore, THREAD_ONLY, SEM_VALUE);
    pthread_t th1,th2;
    pthread_create(&th1,NULL,thread, (void*) 1);
    pthread_create(&th2,NULL,thread, (void*) 2);
    //Join threads with the main thread
    pthread_join(th1,NULL);
    pthread_join(th2,NULL);
    sem_destroy(&semaphore);
}
