//
//  proxy.h
//  DemoProxy
//
//  Created by TungDT on 8/27/20.
//  Copyright © 2020 macOne. All rights reserved.
//

#ifndef proxy_h
#define proxy_h

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <regex.h>

#define MAX_URLS 10
#define URL_LEN 200
#define TRUE 1
#define FALSE 0

typedef struct
{
    int n_urls;
    char urls[MAX_URLS][URL_LEN];
} firewall;

// browser functions
void browse(char* url, int (*access)(char* url, void* fw), void* fw);
void setup_firewall(firewall* f);
void config_proxy(void** access, void** fw);
void clean_proxy(firewall** fw);

// call-back functions
int access_point(char* url, void* fw);
int access_proxy(char* url, void* fw);

// proxy functions
int is_accessible(firewall* f, char* url);
void add_url(firewall* f, char* url);
// access point function
int is_url(char* url);



#endif /* proxy_h */
