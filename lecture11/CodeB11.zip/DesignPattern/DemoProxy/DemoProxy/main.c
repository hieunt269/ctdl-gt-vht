//
//  main.c
//  DemoProxy
//
//  Created by TungDT on 8/27/20.
//  Copyright © 2020 macOne. All rights reserved.
//

#include "proxy.h"


int main(int argc, const char * argv[])
{
    void* access = access_point;
    void* fw = NULL;
    
    browse("http://vnexpress.net", access, fw);
    browse("bbc.com.vn", access, fw);
    browse("google", access, fw);
    
    config_proxy(&access, &fw);
    
    browse("vnexpress.net", access, fw);
    browse("bbc.com.vn", access, fw);
    browse("cornhub.com", access, fw);
    
    clean_proxy((firewall**) &fw);
    
    return 0;
}

