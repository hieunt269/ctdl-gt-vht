//
//  proxy.c
//  DemoProxy
//
//  Created by TungDT on 8/27/20.
//  Copyright © 2020 macOne. All rights reserved.
//

#include "proxy.h"

void browse(char* url, int (*access)(char* url, void* fw), void* fw)
{
    if (access(url, fw))
    {
        printf("[Chrome]: Connected to %s\n", url);
        printf("[Chrome]: Start browsing %s\n", url);
    }
    else
    {
        printf("[Chrome]: Cannot access to %s\n", url);
    }
}

int access_point(char* url, void* fw)
{
    if (!is_url(url))
    {
        printf("[AP]: Invalid ulr!\n");
        return FALSE;
    }
    printf("[AP]: Getting ip address for %s ... done!\n", url);
    return TRUE;
}
int access_proxy(char* url, void* fw)
{
    firewall* f = (firewall*) fw;
    if (!is_accessible(f, url))
    {
        printf("[Proxy]: Access to %s is denied!\n", url);
        return FALSE;
    }
    return access_point(url, NULL);
}

int is_accessible(firewall* f, char* url)
{
    for (int i = 0; i < f->n_urls; i++)
    {
        if (strcmp(f->urls[i], url) == 0) return FALSE;
    }
    return TRUE;
}
void add_url(firewall* f, char* url)
{
    if (f->n_urls == MAX_URLS) return;
    
    strcpy(f->urls[f->n_urls++], url);
}

void setup_firewall(firewall* f)
{
    add_url(f, "cornhub.com");
    add_url(f, "bbc.com.vn");
}

void config_proxy(void** access, void** fw)
{
    
    *access = access_proxy;
    
    firewall *f = (firewall*) malloc(sizeof(firewall));
    f->n_urls = 0;
    setup_firewall(f);
    
    *fw = f;
    printf("\n ~~~~ Proxy configured! ~~~~ \n");
}

void clean_proxy(firewall** fw)
{
    free(*fw);
    *fw = NULL;
}

int is_url(char* url)
{
    regex_t regex;
    char* testurl = "^(https?:\\/\\/)?([\\da-z\\.-]+)\\.([a-z\\.]{2,6})([\\/\\w \\.-]*)*\\/?$";
    
    if (regcomp(&regex, testurl, REG_EXTENDED) != 0) return FALSE;
    
    return regexec(&regex, url, 0, NULL, 0) == 0;
    
}
