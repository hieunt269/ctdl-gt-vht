//
//  pool.c
//  MemoryPoolV3
//
//  Created by TungDT on 8/16/20.
//  Copyright © 2020 macOne. All rights reserved.
//

#include "pool.h"
// create a pool of memory
memory_pool* create_pool(u_int element_size, u_int pool_size)
{
    
    memory_pool *pool = (memory_pool*) malloc(sizeof(memory_pool));
    pool->element_size = element_size;
    pool->pool_size = pool_size;
    pool->pointer = malloc(element_size * pool_size);
    pool->n_avails = 0;
    pool->curr = -1;
    pool->n_freed = 0;
    pool->avails = (ul_int*) malloc(sizeof(ul_int) * pool_size);
    pool->freed = (ul_int*) malloc(sizeof(ul_int) * pool_size);
    for (int i = 0; i < pool_size; i++)
    {
        pool->avails[i] = 0;
        pool->freed[i] = 0;
    }
    return pool;
}
// allocate memory from the pool
void* pool_alloc(memory_pool *pool)
{
    // all memory blocks are allocated & still in use
    if (is_full(pool)) return NULL;
    // all memory blocks are allocated but some are not in use
    pool->curr = find_next(pool);
    if (pool->curr == NOT_AVAILABLE)
    {
        clean_pool(pool);
        pool->curr = find_next(pool);   // find again, this time will get a free block
    }
    
    void* alloc_addr = pool->pointer + pool->curr * pool->element_size;
    pool->avails[pool->curr] = (ul_int) alloc_addr;
    pool->n_avails++;
    return alloc_addr;
}
// free memory pointed by p from the pool
void pool_free(memory_pool *pool, void* p)
{
    // TODO: check if p is already free
    pool->freed[pool->n_freed++] = (ul_int) p;
}
// check if pool is available to allocate
int find_next(memory_pool* pool)
{
    int curr = pool->curr;
    for (int i = 0; i < pool->pool_size; i++)
    {
        curr = (curr + 1) % pool->pool_size;
        if (pool->avails[curr] == 0) return curr;
    }
    return NOT_AVAILABLE;
}
// clean the pool to reuse freed memory
void clean_pool(memory_pool* pool)
{
    for (int i = 0; i < pool->n_freed; i++)
    {
        ul_int addr = pool->freed[i];
        clean_at(pool, addr);
    }
    pool->n_avails -= pool->n_freed;
    pool->n_freed = 0;
}
// delete no longer use pool
void delete_pool(memory_pool* pool)
{
    free(pool->avails);
    free(pool->freed);
    free(pool->pointer);
    free(pool);
}
void clean_at(memory_pool* pool, ul_int addr)
{
    for (int i = 0; i < pool->pool_size; i++)
        if (pool->avails[i] == addr)
        {
            pool->avails[i] = 0;
            break;
        }
}

int is_full(memory_pool* pool)
{
    return pool->n_avails == pool->pool_size && pool->n_freed == 0;
}

void dump(memory_pool *pool)
{
    printf("++++++ POOL INFO ++++++\n");
    printf("Element size    : %d\n", pool->element_size);
    printf("Pool size       : %d\n", pool->pool_size);
    printf("Allocated blocks: %d\n", pool->n_avails);
    printf("Freed blocks    : %d\n", pool->n_freed);
    printf("Allocated       : ");
    for (int i = 0; i < pool->pool_size; i++)
        printf("%ld ", pool->avails[i]);
    printf("\n");
    printf("Freed           : ");
    for (int i = 0; i < pool->n_freed; i++)
        printf("%ld ", pool->freed[i]);
    printf("\n");
}
