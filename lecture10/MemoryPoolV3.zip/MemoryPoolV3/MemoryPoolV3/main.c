//
//  main.c
//  MemoryPoolV3
//
//  Created by TungDT on 8/16/20.
//  Copyright © 2020 macOne. All rights reserved.
//

#include "pool.h"

typedef struct
{
    int x;
    int y;
} position;

int main(int argc, const char * argv[])
{
    memory_pool *pool = create_pool(sizeof(position), 10);
    position *p[10];
    
    for (int i = 0; i < 10; i++)
    {
        p[i] = (position*) pool_alloc(pool);
    }
    for (int i = 0; i < 10; i+=2)
    {
        pool_free(pool, p[i]);
    }
    dump(pool);
    for (int i = 0; i < 10; i+=2)
    {
        pool_alloc(pool);
    }
    dump(pool);
    if (pool_alloc(pool) == NULL) printf("Cannot allocate more!\n");
    delete_pool(pool);
    
    return 0;
}
