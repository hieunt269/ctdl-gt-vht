//
//  pool.h
//  MemoryPoolV3
//
//  Created by TungDT on 8/16/20.
//  Copyright © 2020 macOne. All rights reserved.
//

#ifndef pool_h
#define pool_h

#include <stdio.h>
#include <stdlib.h>

typedef unsigned int u_int;
typedef unsigned long int ul_int;
#define NOT_AVAILABLE -1
typedef struct
{
    u_int element_size; // size of each element
    u_int pool_size;    // size of the whole pool (max number of elements)
    u_int n_avails;     // current number of allocated elements
    u_int curr;         // current available position to allocate
    ul_int* freed;      // address of elements to be freed
    u_int n_freed;      // number of elements to be freed
    ul_int* avails;     // mark available or not when allocating
    void* pointer;      // pointer to the blocks of memory reserved by the pool
} memory_pool;

 // create a pool of memory
memory_pool* create_pool(u_int element_size, u_int pool_size);
// allocate memory from the pool
void* pool_alloc(memory_pool *pool);
// free memory pointed by p from the pool
void pool_free(memory_pool *pool, void* p);
// find next available position to allocate
int find_next(memory_pool *pool);
// clean the pool to reuse freed memory
void clean_pool(memory_pool* pool);
// delete no longer use pool
void delete_pool(memory_pool* pool);
// chekc if pool is full
int is_full(memory_pool* pool);
// clean pool at one specific address
void clean_at(memory_pool* pool, ul_int addr);


void dump(memory_pool *pool);


#endif /* pool_h */

