//
//  main.c
//  MemoryPoolExample
//
//  Created by TungDT on 8/16/20.
//  Copyright © 2020 macOne. All rights reserved.
//

#include "pool.hpp"

int* pool = NULL;
int* bottom = NULL;
int* surface = NULL;
int pool_size = 0;

int main(int argc, const char * argv[])
{
    pool_init(1000);
    int* a = p_malloc(1);
    *a = 5;
    printf("a = %d\n", *a);
    
    int* arr = p_malloc(10);
    for (int i = 0; i < 10; i++)
        arr[i] = i;
    
    for (int i = 0; i < 10; i++)
        printf("arr[%d] = %d\n", i, arr[i]);
    
    pool_free();
    
    return 0;
}
