//
//  pool.cpp
//  MemoryPoolExample
//
//  Created by TungDT on 8/16/20.
//  Copyright © 2020 macOne. All rights reserved.
//

#include "pool.hpp"

void pool_init(int size)
{
    pool = (int*) malloc(sizeof(int) * size);
    surface = pool;
    bottom = pool + size;
    if (!pool)
    {
        printf("Cannot init pool\n");
        exit(1);
    }
}
int* p_malloc(int size)
{
    if (!is_shallow(size))
    {
        int* curr = surface;
        surface += size;
        return curr;
    }
    else return NULL;
}
void pool_free(void)
{
    free(pool);
}

int is_shallow(int size)
{
    return bottom - surface < size;
}
