//
//  pool.hpp
//  MemoryPoolExample
//
//  Created by TungDT on 8/16/20.
//  Copyright © 2020 macOne. All rights reserved.
//

#ifndef pool_hpp
#define pool_hpp

#include <stdio.h>
#include <stdlib.h>

extern int* pool;
extern int* surface;
extern int* bottom;
extern int pool_size;

void pool_init(int size);
int* p_malloc(int size);
void pool_free(void);
int is_shallow(int size);

#endif /* pool_hpp */
