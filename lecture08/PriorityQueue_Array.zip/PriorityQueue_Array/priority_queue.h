
#ifndef priority_queue_h
#define priority_queue_h

#include <stdio.h>
#include <stdlib.h>


extern int front;
extern int rear;
extern int queue[];

void clear_queue(void);
int is_empty(void);
int is_full(void);
void enqueue(const int n);
int dequeue(void);
int size(void);
void overflow(char* msg);
void swap(int a[], const int i, const int j);

#endif /* priority_queue_h */