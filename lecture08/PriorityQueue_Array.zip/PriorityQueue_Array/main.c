
#include <stdio.h>
#include "priority_queue.h"

int front = -1;
int rear = -1;
int queue[14];

int main(int argc, const char * argv[])
{
    int keys[] =       {1, 2, 3, 4, 5, 6, 7};
    int priorities[] = {1, 1, 2, 1, 2, 3, 1};
    int n = 7;
    
    printf("Queue:\n");

    enqueue(keys[0]);
    enqueue(priorities[0]);
    
    for (int i = 1; i < n; i++)
    {
        enqueue(keys[i]);
        enqueue(priorities[i]);

        for (int j = 2*i - 1; j > 0; j = j + 2)
            if (priorities[i] > queue[j])
            {
                swap(queue, j)
            }
    }

    print_queue(queue);
    
    // printf("Dequeue:\n");
    // while (!is_empty())
    // {
    //     element e = dequeue(queue);
    //     printf("[%d, %d, %d] ", e.key, e.priority, e.order);
    // }
    // printf("\n");
    
    return 0;
}